#!/bin/python

# Author: Jon Garry
# Date: 2016-07-17
# Last modified: 2019-02-13
#
# Description:  Script applies Chung-Kennedy filter to simulated fluorophore bleach curves.
#               The initial number of fluorophores, n0, is estimated using calibrated
#               photophysical parameters.

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def main():
  
    # Define C-K window size and estimated parameters
    w = 8
    nu = 400    # step size
    a = 1000   # background

    # NOTE: included example trace was simulated with the following parameters:
    # n0 = 25
    # nu = 400
    # a = 1000

    # Load trace data
    data = np.loadtxt("example_high-snr_trace.txt")

    t = data[:,0]
    I = data[:,1]
    N = len(t)
   
    # Compute CK filtered signal
    I_filt = CK_filter(I, w, 25)

    # Estimate n0
    n0 = int(np.round((I_filt[0] - a) / nu))
   
    print("Estimated n0:", n0)



    # Plot original trace with C-K filtered trace:
    # ----------------------------------------------------------------------

    sns.set_style("ticks", {"xtick.direction":"in", "ytick.direction":"in"})
    plt.rcParams["font.family"] = "sans-serif"

    fig,ax = plt.subplots()
    fig.set_tight_layout(True)
    ax.set_xlabel("t (s)")
    ax.set_ylabel("I (arbitrary units)")
    
    plt.plot(t, I, 'k-', label="Intensity Trace")
    plt.plot(t, I_filt, 'r-', label="C-K Filtered Trace")
    
    plt.legend(loc="upper right")

    plt.show()


def CK_filter(I, w, r):
# Chung-Kennedy filter
# Inputs: I input intensity, w window size, r sensitivity (1 << r < 100)

    N = len(I)
    I_filt = np.zeros(N,float)
    T = np.zeros(N,float)

    # Pad front of filtered signal with mean of first w points
    I_filt[:w] = np.mean(I[:w])
    
    # Calculate mean over first w points:
    for i in range(w,N-w):
        FW = I[i+1:i+w+1]       # define forward window
        BW = I[i-w:i]		# define adjacent backward window

        mu1 = np.mean(FW)
        mu2 = np.mean(BW)

        s1 = np.var(FW, ddof=1)
        s2 = np.var(BW, ddof=1)

        # Calculate weights
        g1 = s2**r / (s1**r + s2**r)
        g2 = s1**r / (s1**r + s2**r)

        # Calculate filtered signal
        I_filt[i] = g1*mu1 + g2*mu2

        # Calculate T-test statistic:
        # ==================================================================================
        #S = np.sqrt(g1*s1 + g2*s2)
        #T[i] = (mu1 - mu2) / S
        # ==================================================================================
    
    # Pad end of filtered signal with mean of last w points
    I_filt[-w:] = np.mean(I[-w:])
    
    #return I_filt, T
    return I_filt



if __name__ == '__main__':
    main()
