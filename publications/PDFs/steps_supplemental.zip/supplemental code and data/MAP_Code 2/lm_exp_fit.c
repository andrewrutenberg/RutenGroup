/*
Code is a modified version of the exponential fit example in the 
GSL documentation.
Uses L-M algorithm to perform a nonlinear least squares fitting to
an exponential function with background: a*e^(-rate*t) + b
*/
#include "lm_exp_fit.h"

/* model functions for exponential + background */
int expb_f(const gsl_vector *x, void *data, gsl_vector *f) {
    size_t n = ((struct data *)data)->n;
    double *y = ((struct data *)data)->y;

    double A = gsl_vector_get(x, 0);
    double lambda = gsl_vector_get(x, 1);
    double b = gsl_vector_get(x, 2);

    size_t i;

    for (i = 0; i < n; i++) {
        /* Model Yi = A * exp(-lambda * i) + b */
        double t = i;
        double Yi = A * exp(-lambda * t) + b;
        gsl_vector_set(f, i, Yi - y[i]);
    }

    return GSL_SUCCESS;
}

int expb_df(const gsl_vector *x, void *data, gsl_matrix *J) {
    size_t n = ((struct data *)data)->n;

    double A = gsl_vector_get (x, 0);
    double lambda = gsl_vector_get (x, 1);

    size_t i;

    for (i = 0; i < n; i++) {
        /* Jacobian matrix J(i,j) = dfi / dxj, */
        /* where fi = (Yi - yi)/sigma[i],      */
        /*       Yi = A * exp(-lambda * i) + b  */
        /* and the xj are the parameters (A,lambda,b) */
        double t = i;
        double e = exp(-lambda * t);
        gsl_matrix_set(J, i, 0, e); 
        gsl_matrix_set(J, i, 1, -t * A * e);
        gsl_matrix_set(J, i, 2, 1.0);
    }
    
    return GSL_SUCCESS;
}

void calc_exp_fit(double *y, int N, double *rate, double *a, double *b) {
    /* 
    int N;
    N = get_record_count("data/test_n5.txt");
    
    // load data 
    double y[N], t[N];
    load_exp_data("data/test_n5.txt", N, y, t);
    */
    
    // initialise LM solver
    const gsl_multifit_fdfsolver_type *T = gsl_multifit_fdfsolver_lmsder;
    gsl_multifit_fdfsolver *s;
    
    int status, info;
    size_t i;
    const size_t n = N;
    const size_t p = 3;
    
    gsl_matrix *J = gsl_matrix_alloc(n, p);
    gsl_matrix *covar = gsl_matrix_alloc(p, p);
    
    struct data d = { n, y };
    gsl_multifit_function_fdf f;
   
    // set initial guess
    double x_init[3] = {y[0], 0.01, y[N-1]};
    gsl_vector_view x = gsl_vector_view_array(x_init, p);
    gsl_vector *res_f;
    
    double chi, chi0;
    const double xtol = 1e-8;
    const double gtol = 1e-8;
    const double ftol = 0.0;

    f.f = &expb_f;
    f.df = &expb_df; /* set to NULL for finite-difference Jacobian */
    f.n = n;
    f.p = p;
    f.params = &d;
    
    s = gsl_multifit_fdfsolver_alloc(T, n, p);
    
    /* initialize solver with starting point */
    gsl_multifit_fdfsolver_set(s, &f, &x.vector);

    /* compute initial residual norm */
    res_f = gsl_multifit_fdfsolver_residual(s);
    chi0 = gsl_blas_dnrm2(res_f);

    /* solve the system with a maximum of 20 iterations */
    status = gsl_multifit_fdfsolver_driver(s, 20, xtol, gtol, ftol, &info);

    gsl_multifit_fdfsolver_jac(s, J);
    gsl_multifit_covar(J, 0.0, covar);

    /* compute final residual norm */
    chi = gsl_blas_dnrm2(res_f);

#define FIT(i) gsl_vector_get(s->x, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))

    /* Full algorithm output */
    /*
    fprintf(stderr, "\nsummary from method '%s'\n", gsl_multifit_fdfsolver_name(s));
    fprintf(stderr, "number of iterations: %zu\n", gsl_multifit_fdfsolver_niter(s));
    fprintf(stderr, "function evaluations: %zu\n", f.nevalf);
    fprintf(stderr, "Jacobian evaluations: %zu\n", f.nevaldf);
    fprintf(stderr, "reason for stopping: %s\n", (info == 1) ? "small step size" : "small gradient");
    fprintf(stderr, "initial |f(x)| = %g\n", chi0);
    fprintf(stderr, "final   |f(x)| = %g\n", chi);

    { 
        double dof = n - p;
        double c = GSL_MAX_DBL(1, chi / sqrt(dof)); 

        fprintf(stderr, "chisq/dof = %g\n",  pow(chi, 2.0) / dof);

        fprintf (stderr, "A      = %.5f +/- %.5f\n", FIT(0), c*ERR(0));
        fprintf (stderr, "lambda = %.5f +/- %.5f\n", FIT(1), c*ERR(1));
        fprintf (stderr, "b      = %.5f +/- %.5f\n", FIT(2), c*ERR(2));
    }

    fprintf (stderr, "status = %s\n", gsl_strerror(status));
    */

    // Assign fit parameters to variables from calling function
    *a = FIT(0);
    *rate = FIT(1);
    *b = FIT(2);

    gsl_multifit_fdfsolver_free(s);
    gsl_matrix_free(covar);
    gsl_matrix_free(J);

}

