/*
Author: Jon Garry
Date Created: 2016-05-10
Date Last Modified: 2017-05-08
Description:    Program for performing Bayesian inference fitting with n-dependent noise.
                This version fits to curves given known photophysical parameters and searches
                through a given range of n0 (MIN_N0, MAX_N0)
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "lm_exp_fit.h"
#include "utility_functions.h"
#include "bayes_functions.h"

int MIN_N0, MAX_N0;

void calc_fit(double *I, double *t, int *n, double *L, int N, int n0, int *change_pts, double rate, double nu, double a, double sig0_sq, double sig1_sq);
void resample(double *I, double *t, int *n, double *L, int N, int n0, int *change_pts, double rate, double nu, double a, double sig0_sq, double sig1_sq);

int main(int argc, char *argv[]) {
     
    // File names and paths
    char fname[30], input_path[60], I_output_path[60], n_output_path[60], params_output_path[60], fnum_buffer[5], fnum[5], seed_fname[60];
    char n0_L_exp[60], n0_L_test[60];
    int exp_fit;

    switch(argc) {
        case 4: // Fitting experimental data
            exp_fit = 1;
            
            strcpy(fname, argv[1]);
            strcpy(seed_fname, fname);
            
            MIN_N0 = atoi(argv[2]);
            MAX_N0 = atoi(argv[3]);

            strcpy(input_path, "./exp_data/datasets/");
            strcat(input_path, fname);
            strcat(input_path, ".txt");
            
            strcpy(I_output_path, "./exp_data/");
            strcat(I_output_path, fname);
            strcat(I_output_path, "/I_vs_t-fit.txt");

            strcpy(n_output_path, "./exp_data/");
            strcat(n_output_path, fname);
            strcat(n_output_path, "/n_vs_t-fit.txt");

            strcpy(params_output_path, "./exp_data/");
            strcat(params_output_path, fname);
            strcat(params_output_path, "/fit_params.txt");

            strcpy(n0_L_exp, "./exp_data/");
            strcat(n0_L_exp, fname);
            strcat(n0_L_exp, "/L_vs_n0.txt");
            
            break;
        case 5: // Fitting test data
            exp_fit = 0;
            
            strcpy(fname, argv[1]);
            strcpy(fnum_buffer, argv[2]);
            
            MIN_N0 = atoi(argv[3]);
            MAX_N0 = atoi(argv[4]);

            // Pad leading zeros to fnum if required
            switch(strlen(fnum_buffer)){
                case 1:
                    strcpy(fnum, "000");
                    strcat(fnum, fnum_buffer);
                    break;
                case 2:
                    strcpy(fnum, "00");
                    strcat(fnum, fnum_buffer);
                    break;
                case 3:
                    strcpy(fnum, "0");
                    strcat(fnum, fnum_buffer);
                    break;
                default:
                    strcpy(fnum, fnum_buffer);
                    break;
            }  

            strcpy(seed_fname, fnum);
            strcat(seed_fname, "-");
            strcat(seed_fname, fname);

            strcpy(input_path, "./test_data/");
            strcat(input_path, fname);
            strcat(input_path, "/");
            strcat(input_path, fnum);
            strcat(input_path, "-I_vs_t.txt");
            
            strcpy(I_output_path, "./test_data/");
            strcat(I_output_path, fname);
            strcat(I_output_path, "/fits_pp/");
            strcat(I_output_path, fnum);
            strcat(I_output_path, "-I_vs_t-fit.txt");

            strcpy(n_output_path, "./test_data/");
            strcat(n_output_path, fname);
            strcat(n_output_path, "/fits_pp/");
            strcat(n_output_path, fnum);
            strcat(n_output_path, "-n_vs_t-fit.txt");

            strcpy(params_output_path, "./test_data/");
            strcat(params_output_path, fname);
            strcat(params_output_path, "/fits_pp/");
            strcat(params_output_path, fnum);
            strcat(params_output_path, "-fit_params.txt");
            
            strcpy(n0_L_test, "./test_data/");
            strcat(n0_L_test, fname);
            strcat(n0_L_test, "/fits_pp/");
            strcat(n0_L_test, fnum);
            strcat(n0_L_test, "-L_vs_n0.txt");
            
            break;
        default:
            printf("\nUsage: \nExperimental data: ./fitting filename min_n0 max_n0 \nTest data: ./fitting_SA filename filenum min_n0 max_n0\n\n");
            return 1;
    }
    
    if (MIN_N0 > MAX_N0) {
        printf("\nmin_n0 must be smaller than max_n0...\n\n");
        return 1;
    }  
 
    // Seed RNG
    unsigned seed;
    seed = rdtsc();
    save_seed("fitting", seed_fname, seed);
    srandom(seed);
   
    // Declare arrays/vars and load dataset
    int N = get_record_count(input_path);
    int L_len = (MAX_N0 - MIN_N0) + 1;
    
    double I[N], t[N], L[L_len], nu, a, q, sig0_sq, sig1_sq, I_fit[N];
    int n_var[N][L_len], n[N], max_idx;

    
    if(exp_fit) {
        load_exp_data(input_path, N, I, t);
    }
    else {
        load_test_data(input_path, N, I, t);
    }
    
    // Perform exponential fit to estimate decay rate
    double rate, est_I0, est_a;
    calc_exp_fit(I, N, &rate, &est_I0, &est_a);
    
    // routine failed if rate is negative ... set to something non-negative
    if(rate < 0) { 
        rate = 0.01; 
    }
    
    printf("\nEstimated bleach rate = %f\n", rate);

    // Perform fit with n0 = 0 if min_n0 = 0
    int idx, first_n0;
    if(MIN_N0 == 0) {    
        calc_zero_params(I, N, &nu, &a, &q, &sig0_sq, &sig1_sq);
        L[0] = calc_zero_L(I, N, a, sig0_sq);
        
        if(exp_fit) {
            save_n0_L(n0_L_exp, 0, L[0]);
        }
        else {
            save_n0_L(n0_L_test, 0, L[0]);
        }

        // set start of for-loop to 1
        idx = 1;
        first_n0 = 1;
    }
    else {
        // set start of for-loop to 0
        idx = 0;
        first_n0 = MIN_N0;
    }

    // =======================================================================
    // Assuming known parameters (values used to generate the model):
    
    // placeholder variables for unused parameter values from file
    int tmp_n0;
    double tmp_L; 

    // construct path
    char params_input_path[60];
    strcpy(params_input_path, "./test_data/");
    strcat(params_input_path, fname);
    strcat(params_input_path, "/gen_params.txt"); 
    load_exp_fit_params(params_input_path, &tmp_n0, &nu, &a, &q, &sig0_sq, &sig1_sq, &tmp_L);

    //printf("\n%s, %d, %f, %f, %.4f, %f, %f, %f\n", params_input_path, tmp_n0, nu, a, q, sig0_sq, sig1_sq, tmp_L);
    // =======================================================================
    
    // Perform fit for range of n0 values:
    for(int i = idx, n0 = first_n0; i < L_len; i++, n0++) {
        int change_pts[n0];
       
        printf("\nTrying n0 = %d\n", n0);
        calc_fit(I, t, n, &L[i], N, n0, change_pts, rate, nu, a, sig0_sq, sig1_sq);
       
        /*
        // Resample for n0 > 2 ... attempt to find larger log-post values
        if(n0 > 2) {
            resample(I, t, n, &L[i], N, n0, change_pts, rate, nu, a, sig0_sq, sig1_sq);
        }
        */

        // Track {n} for each n0
        // Note: This is a trade-off between rewriting all of the functions to accept 2D arrays 
        // or putting up with the performance hit of copying a 1d to a 2d array.
        for(int j = 0; j < N; j++) {
            n_var[j][i] = n[j];
        }
        
        // Output maximum L value for each n0 to file
        if(exp_fit) {
            save_n0_L(n0_L_exp, n0, L[i]);
        }
        else {
            save_n0_L(n0_L_test, n0, L[i]);
        }

    }
    
    max_idx = find_max_idx(L, sizeof(L)/sizeof(double));

    printf("\n");
    for(int i = 0; i < L_len ; i++) {
        printf("L[%d] = %f, n[%d] = %d\n", i, L[i], 0, n_var[0][i]);
    }

    // Check if n0 = 0
    if(max_idx == 0 && MIN_N0 == 0) {
        for(int i = 0; i < N; i++) {
            n[i] = 0;
        }

        calc_zero_params(I, N, &nu, &a, &q, &sig0_sq, &sig1_sq);
    }
    else {
        for(int i = 0; i < N; i++) {
            n[i] = n_var[i][max_idx];
        }
        
        calc_q(n, I, N, &q);
    }
    
    // Generate fit
    for(int i = 0; i < N; i++) {
        I_fit[i] = nu*n[i] + a;
    }
    
    printf("\nVariable noise params:\n");
    printf("Best n_0 = %d\n", n[0]);
    printf("nu = %f\n", nu);
    printf("a = %f\n", a);
    printf("q = %f\n", q);
    printf("sig0_sq = %f\n", sig0_sq);
    printf("sig1_sq = %f\n", sig1_sq);
    printf("L = %f\n", L[max_idx]);
    
    // Save n and I_fit to file
    save_n(n_output_path, N, t, n);
    save_I(I_output_path, N, t, I_fit);
    
    // Save fitting parameters to file
    if(exp_fit) {
        save_exp_fit_params(params_output_path, n[0], nu, a, q, sig0_sq, sig1_sq, L[max_idx]); 
    }
    else {
        save_test_fit_params(params_output_path, atoi(fnum), n[0], nu, a, q, sig0_sq, sig1_sq, L[max_idx]); 
    }
    
    return 0;
}

void calc_fit(double *I, double *t, int *n, double *L, int N, int n0, int *change_pts, double rate, double nu, double a, double sig0_sq, double sig1_sq) {
    
    double q, curr_L;
 
    // Generate initial distribution to put change points in place
    for(int i = 0; i < N; i++) {
        n[i] = round(n0 * exp(-t[i] * rate));
    }
    // Ensure initial {n} goes to zero
    n[N-1] = 0;

    // Get changepoint locations
    get_change_pts(n, N, change_pts);

    // Calculate initial parameters and resulting log posterior
    calc_q(n, I, N, &q);
    curr_L = calc_L(n, I, N, nu, a, q, sig0_sq, sig1_sq);
    
    // Cycle through each changepoint
    int updates, loop_count = 0, curr_cp, new_cp, lbound, ubound, max_idx;
    do {
        // Debug output
        // ===================================
        //loop_count += 1;
        //printf("\nIteration: %d\n", loop_count);
        // ===================================
        updates = 0;
        
       
        // Cycle through each cp
        for(int cp_idx = 0; cp_idx < n0; cp_idx++) {
            curr_cp = change_pts[cp_idx];
        
            // Set bounds of changepoint
            // Check if more than one cp
            if(n0 > 1) {
                // cp at start
                if(cp_idx == 0) {
                    lbound = 1;
                    ubound = change_pts[cp_idx+1];
                }
                // cp at end
                else if(cp_idx == (n0-1)) {
                    lbound = change_pts[cp_idx-1];
                    ubound = N-1;
                }       
                // cp between others
                else {
                    lbound = change_pts[cp_idx-1];
                    ubound = change_pts[cp_idx+1];
                }
            } 
            // Only one cp to move
            else {
                lbound = 1;
                ubound = N-1;
            }
            
            //printf("idx = %d, lbound = %d, ubound = %d\n", cp_idx, lbound, ubound); 
            
            // Initialise array of L values for each cp location
            double L_vals[(ubound+1)-lbound];

            // Remove selected changepoint 
            remove_changepoint(n, lbound, curr_cp);
            
            // Check if cp can be moved (can be in a stack)
            if(ubound-lbound > 0) {
                
                // Cycle cp over range
                int L_idx = 0;
                for(int i = lbound; i < ubound; i++) {
                    
                    // Calculate L for current config
                    calc_q(n, I, N, &q);
                    L_vals[L_idx] = calc_L(n, I, N, nu, a, q, sig0_sq, sig1_sq);
                        
                    n[i] += 1;
                    L_idx += 1;
                } 
                
                // Calc L for last config
                calc_q(n, I, N, &q);
                L_vals[L_idx] = calc_L(n, I, N, nu, a, q, sig0_sq, sig1_sq);

                // Remove cp from last location
                remove_changepoint(n, lbound, ubound);
            }
            // skip changepoint otherwise
            else {
                calc_q(n, I, N, &q);
                L_vals[0] = calc_L(n, I, N, nu, a, q, sig0_sq, sig1_sq);
            }

            // Get index of largest L value
            max_idx = find_max_idx(L_vals, sizeof(L_vals)/sizeof(double));
            new_cp = lbound + max_idx;

            // Check if L was increased
            if(L_vals[max_idx] > curr_L) {
                
                // debug output
                // ==============================================================
                //printf("Changepoint at %d moved to %d.\n", curr_cp, new_cp);
                //printf("Old L: %f, New L: %f\n", curr_L, L_vals[max_idx]);
                // ==============================================================
                
                // Place changepoint in position associated with max L
                add_changepoint(n, lbound, new_cp);

                // Update changepoints array
                change_pts[cp_idx] = new_cp;
                
                // Update current L value
                curr_L = L_vals[max_idx];
                
                // Increment updates counter
                updates += 1;
            }
            else {
                // Otherwise return changepoint to original position
                add_changepoint(n, lbound, curr_cp);
            }
            
        }
    } while(updates != 0);
   
    printf("\nInitial fit L = %f\n", curr_L);
    printf("Changepoints: ");
        for(int k=0; k<n0; k++) {
            printf("%d ", change_pts[k]);
        }
        printf("\n");

    *L = curr_L;
}

void resample(double *I, double *t, int *n, double *L, int N, int n0, int *change_pts, double rate, double nu, double a, double sig0_sq, double sig1_sq) {
// This function is basically a copy-paste of calc_fit() with the intial n dist generated using Gillespie

    double q, curr_L;
    int n2[N];   
    
    // calculated estimated q from exponential rate
    //q = exp(-1*(t[1] - t[0])*rate);

    // re-fit using random Gillespie-generated initial {n_i} m times
    for(int m = 1; m <= 5; m++) { 
        
        // Generate initial distribution using Gillespie algorithm
        generate_n(n2, t, N, n0, q);
        
        // Get changepoint locations
        get_change_pts(n2, N, change_pts);

        // Calculate initial parameters and resulting log posterior
        calc_q(n2, I, N, &q);
        curr_L = calc_L(n2, I, N, nu, a, q, sig0_sq, sig1_sq);
        
        // Cycle through each changepoint
        int updates, loop_count = 0, curr_cp, new_cp, lbound, ubound, max_idx;
        do {
            // Debug output
            // ===================================
            //loop_count += 1;
            //printf("\nIteration: %d\n", loop_count);
            // ===================================
            updates = 0;
            
            // Cycle through each cp
            for(int cp_idx = 0; cp_idx < n0; cp_idx++) {
                curr_cp = change_pts[cp_idx];
            
                // Set bounds of changepoint
                // Check if more than one cp
                if(n0 > 1) {
                    // cp at start
                    if(cp_idx == 0) {
                        lbound = 1;
                        ubound = change_pts[cp_idx+1];
                    }
                    // cp at end
                    else if(cp_idx == (n0-1)) {
                        lbound = change_pts[cp_idx-1];
                        ubound = N-1;
                    }       
                    // cp between others
                    else {
                        lbound = change_pts[cp_idx-1];
                        ubound = change_pts[cp_idx+1];
                    }
                } 
                // Only one cp to move
                else {
                    lbound = 1;
                    ubound = N-1;
                }
                
                // Initialise array of L values for each cp location
                double L_vals[(ubound+1)-lbound];

                // Remove selected changepoint 
                remove_changepoint(n2, lbound, curr_cp);
                
                // Check if cp can be moved (can be in a stack)
                if(ubound-lbound > 0) {
                    
                    // Cycle cp over range
                    int L_idx = 0;
                    for(int i = lbound; i < ubound; i++) {
                        
                        // Calculate L for current config
                        calc_q(n2, I, N, &q);
                        L_vals[L_idx] = calc_L(n2, I, N, nu, a, q, sig0_sq, sig1_sq);
                            
                        n2[i] += 1;
                        L_idx += 1;
                    } 
                    
                    // Calc L for last config
                    calc_q(n2, I, N, &q);
                    L_vals[L_idx] = calc_L(n2, I, N, nu, a, q, sig0_sq, sig1_sq);

                    // Remove cp from last location
                    remove_changepoint(n2, lbound, ubound);
                }
                // skip changepoint otherwise
                else {
                    
                    calc_q(n2, I, N, &q);
                    L_vals[0] = calc_L(n2, I, N, nu, a, q, sig0_sq, sig1_sq);
                }

                // Get index of largest L value
                max_idx = find_max_idx(L_vals, sizeof(L_vals)/sizeof(double));
                new_cp = lbound + max_idx;

                // Check if L was increased
                if(L_vals[max_idx] > curr_L) {
                    
                    // debug output
                    // ==============================================================
                    //printf("Changepoint at %d moved to %d.\n", curr_cp, new_cp);
                    //printf("Old L: %f, New L: %f\n", curr_L, L_vals[max_idx]);
                    // ==============================================================
                    
                    // Place changepoint in position associated with max L
                    add_changepoint(n2, lbound, new_cp);

                    // Update changepoints array
                    change_pts[cp_idx] = new_cp;
                    
                    // Update current L value
                    curr_L = L_vals[max_idx];
                    
                    // Increment updates counter
                    updates += 1;
                }
                else {
                    // Otherwise return changepoint to original position
                    add_changepoint(n2, lbound, curr_cp);
                }
                
            }
        } while(updates != 0);
       
        printf("\nResampled fit %d:\nL = %f\n", m, curr_L);
        printf("Changepoints: ");
        for(int k=0; k<n0; k++) {
            printf("%d ", change_pts[k]);
        }
        printf("\n");

        // Check if resampled fit is better
        if(curr_L > *L) {
            
            // Update L and n
            *L = curr_L;

            for(int i = 0; i < N; i++) {
                n[i] = n2[i];
            }

            printf("Updated L and n\n");

        }
    }
}
