/*
Author: Jon Garry
Date Created: 2016-05-10
Date Last Modified: 2016-06-06
Description: Header file for utility functions used by other routines
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// RNG
unsigned long long rdtsc();
void save_seed(char *prog_name, char *fname, unsigned seed);

// math
int factorial(int n);

// arrays
void shuffle(int *arr, int length);
void sort_asc(int *arr, int length);
void sort_desc(int *arr, int length);


// file io
int get_record_count(char *path);
void load_exp_data(char *path, int record_count, double *I, double *t);
void load_test_data(char *path, int record_count, double *I, double *t);
void save_n(char *path, int record_count, double *t, int *n);
void save_I(char *path, int record_count, double *t, double *I);
void save_exp_fit_params(char *path, int n0, double nu, double a, double q, double sig0_sq, double sig1_sq, double L);
void load_exp_fit_params(char *path, int *n0, double *nu, double *a, double *q, double *sig0_sq, double *sig1_sq, double *L);
void save_test_fit_params(char *path, int fnum, int n0, double nu, double a, double q, double sig0_sq, double sig1_sq, double L);
void save_n0_L(char *path, int n0, double L);
