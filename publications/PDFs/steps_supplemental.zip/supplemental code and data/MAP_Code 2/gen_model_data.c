/*
Author: Jon Garry
Date Created: 2016-05-04
Date Last Modified: 2016-05-18
Description:    Routine for generating modeled fluorophore bleaching curves from the parameters returned
                from a fitted data set.
                This is the original version used to simulate curves with camera exposure considerations
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "utility_functions.h"
#include "bayes_functions.h"

int main(int argc, char *argv[]) {
    
    int num_sets = 1;
    char fname[30], fnum[5];
    
    if(argc == 2) {
        strcpy(fname, argv[1]);
    }
    else {
        printf("Usage: ./gen_model_data filename\n");
        return 1;
    }
    
    // Seed RNG
    unsigned seed;
    seed = rdtsc();
    save_seed("gen_model_data", fname, seed);
    srandom(seed);
    
    // Create paths for input files    
    char params_input_path[60]; 
    strcpy(params_input_path, "./exp_data/");
    strcat(params_input_path, fname);
    strcat(params_input_path, "/fit_params.txt");
   
    /* 
    char exp_input_path[60]; 
    strcpy(exp_input_path, "./exp_data/datasets/");
    strcat(exp_input_path, fname);
    strcat(exp_input_path, ".txt");
    */
   
    char fit_params_output_path[60];
    strcpy(fit_params_output_path, "./test_data/");
    strcat(fit_params_output_path, fname);
    strcat(fit_params_output_path, "/");
    strcat(fit_params_output_path, "gen_params.txt");

    // Load fitting paramers
    int n0;
    double nu, a, q, sig0_sq, sig1_sq, L;
    
    load_exp_fit_params(params_input_path, &n0, &nu, &a, &q, &sig0_sq, &sig1_sq, &L);
    
    printf("\nGenerating modeled data with the following parameters:\n");
    printf("n0 = %d \nnu = %f \na = %f \nq = %f \nsig0_sq = %f \nsig1_sq = %f \n\n", n0, nu, a, q, sig0_sq, sig1_sq);
    
    /*
    // Load experimental data to use time series
    int record_count = get_record_count(exp_input_path);
    int n[record_count];
    double t[record_count], I[record_count];
    
    load_exp_data(exp_input_path, record_count, I, t);
    */

    // _OR_ Generate data with defined record count and timestep

    int record_count = 2000;
    double time_step = 0.3; 
    int n[record_count];
    double t[record_count], I[record_count];

    for(int i = 0; i < record_count; i++) {
        t[i] = i * time_step;    
    }

    // Generate test datasets
    char str_buffer[5];
    for(int i = 0; i < num_sets; i++) {
        // Create file num string for output paths
        sprintf(str_buffer, "%d",i+1);
        
        switch(strlen(str_buffer))
        {
            case 1:
                strcpy(fnum, "000");
                break;
            case 2:
                strcpy(fnum, "00");
                break;
            case 3:
                strcpy(fnum, "0");
                break;
            default:
                strcpy(fnum, "");
                break;
        }
        strcat(fnum, str_buffer);
        
        // Create paths for output 
        char I_output_path[60]; 
        strcpy(I_output_path, "./test_data/");
        strcat(I_output_path, fname);
        strcat(I_output_path, "/");
        strcat(I_output_path, fnum);
        strcat(I_output_path, "-I_vs_t.txt"); 
        
        char n_output_path[60];
        strcpy(n_output_path, "./test_data/");
        strcat(n_output_path, fname);
        strcat(n_output_path, "/");
        strcat(n_output_path, fnum);
        strcat(n_output_path, "-n_vs_t.txt");

        // Generate n and I distributions
        generate_n(n, t, record_count, n0, q);
        generate_I(I, n, record_count, nu, a, sig0_sq, sig1_sq);

        // Output arrays to file
        save_n(n_output_path, record_count, t, n);
        save_I(I_output_path, record_count, t, I);
        save_exp_fit_params(fit_params_output_path, n[0], nu, a, q, sig0_sq, sig1_sq, 0.0);

	printf("Generated set %d\n", i+1); 
    }
    
    printf("Completed.\n");
    
    return 0;
}
