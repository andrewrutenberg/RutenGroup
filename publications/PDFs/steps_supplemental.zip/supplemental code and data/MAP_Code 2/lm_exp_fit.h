#include <stdlib.h>
#include <stdio.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_multifit_nlin.h>

struct data {
    size_t n;
    double * y;
};

int expb_f (const gsl_vector *x, void *data, gsl_vector *f);
int expb_df (const gsl_vector *x, void *data, gsl_matrix *J);
void calc_exp_fit(double *y, int N, double *rate, double *a, double *b);
