/*
Author: Jon Garry
Date Created: 2017-06-06
Date Last Modified: 2017-07-07
Description:    Routine for generating modelled fluorophore bleaching curves from the parameters returned
                from a fitted data set. This program accounts for the effects of multiple bleaching events occuring within single 
                camera exposures, ie. the intensity is effectively an average of photon count over the exposure time.
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "utility_functions.h"
#include "bayes_functions.h"

int main(int argc, char *argv[]) {
    
    int num_sets = 1;
    char fname[30], fnum[5];
    
    if(argc == 2) {
        strcpy(fname, argv[1]);
    }
    else {
        printf("Usage: ./gen_model_data filename\n");
        return 1;
    }
    
    // Seed RNG
    unsigned seed;
    //seed = 1337;
    seed = rdtsc();
    save_seed("gen_sim_data", fname, seed);
    srandom(seed);
    
    // Create paths for input files and output parameters
    char params_input_path[60]; 
    strcpy(params_input_path, "./exp_data/");
    strcat(params_input_path, fname);
    strcat(params_input_path, "/fit_params.txt");
   
    char exp_input_path[60]; 
    strcpy(exp_input_path, "./exp_data/datasets/");
    strcat(exp_input_path, fname);
    strcat(exp_input_path, ".txt");
    
    char fit_params_output_path[60];
    strcpy(fit_params_output_path, "./test_data/");
    strcat(fit_params_output_path, fname);
    strcat(fit_params_output_path, "/");
    strcat(fit_params_output_path, "gen_params.txt");

    // Load fitting paramers
    int n0;
    double nu, a, q, sig0_sq, sig1_sq, L;
    
    load_exp_fit_params(params_input_path, &n0, &nu, &a, &q, &sig0_sq, &sig1_sq, &L);
    printf("\nGenerating modeled data with the following parameters:\n");
    printf("n0 = %d \nnu = %f \na = %f \nq = %f \nsig0_sq = %f \nsig1_sq = %f \n\n", n0, nu, a, q, sig0_sq, sig1_sq);
    
    // ===============================================================   
   
    /* 
    // ---------------------------------------------------------------
    // Load experimental data to use time series -> time step and last timepoint
    int record_count = get_record_count(exp_input_path);
    double t[record_count], I[record_count], dt_full, max_t;
    int n[record_count];
    
    load_exp_data(exp_input_path, record_count, I, t);
    dt_full = t[1] - t[0];
    max_t = t[record_count-1];
    // ---------------------------------------------------------------
    */

    // ---------------------------------------------------------------
    // _OR_ Generate data with defined record count and timestep
    //double dt_full = 0.3;     // timestep of measured data in seconds
    //double max_t = 300;         // Max time in experimental datasets (seconds)
    double dt_full = 0.3;    
    double max_t = 300;         // Max time in experimental datasets (seconds)
    
    int record_count = max_t / dt_full;
    double t[record_count], I[record_count];
    int n[record_count];
    // ---------------------------------------------------------------
    
    // Generate times for intensity series
    t[0] = 0.0;
    for(int i = 1; i < record_count; i++) {
        t[i] = t[i-1] + dt_full;    
    }
    // ===============================================================   
    
    // Calculate fluorophore lifetime
    double tau = -dt_full / log(q); 
    
    printf("Time-step in data: %f\n", dt_full);
    printf("Last timepoint: %f\n", max_t);
  
    // Generate test datasets
    char str_buffer[5];
    for(int dataset = 1; dataset <= num_sets; dataset++) {
        // Create file num string for output paths
        sprintf(str_buffer, "%d", dataset);
        
        switch(strlen(str_buffer))
        {
            case 1:
                strcpy(fnum, "000");
                break;
            case 2:
                strcpy(fnum, "00");
                break;
            case 3:
                strcpy(fnum, "0");
                break;
            default:
                strcpy(fnum, "");
                break;
        }
        strcat(fnum, str_buffer);
        
        // Create paths for output 
        char I_output_path[60]; 
        strcpy(I_output_path, "./test_data/");
        strcat(I_output_path, fname);
        strcat(I_output_path, "/");
        strcat(I_output_path, fnum);
        strcat(I_output_path, "-I_vs_t.txt"); 
        
        char n_output_path[60];
        strcpy(n_output_path, "./test_data/");
        strcat(n_output_path, fname);
        strcat(n_output_path, "/");
        strcat(n_output_path, fnum);
        strcat(n_output_path, "-n_vs_t.txt");
        
        
        // Generate bleach times using Gillespie/kMC
        // ============================================================================================
 
        double bleach_steps[n0], t_bleach[n0], total_time;
        for(int i = 0; i < n0; i++) {
            bleach_steps[i] = (-tau/(n0-i)) * log(1 - ((double)random() / RAND_MAX));
        }          
 
        // Generate time series from bleach steps 
        t_bleach[0] = bleach_steps[0];
        for(int i = 1; i < n0; i++) {
            t_bleach[i] = t_bleach[i-1] + bleach_steps[i];
        }   
        
        /*
        printf("\nKMC bleach steps: [ ");
        for(int i = 0; i < n0; i++) {
            printf("%f ", bleach_steps[i]);
        } 
        printf("]\n");
        
        printf("\nBleach time series: [ ");
        for(int i = 0; i < n0; i++) {
            printf("%f ", t_bleach[i]);
        } 
        printf("]\n");
        */

        // Generate naïve fluorophore count time series n (best for sets that have extremely fast bleaching)
        // ============================================================================================
        int bleach_count = 0;
        n[0] = n0;
        for(int i = 1; i < record_count; i++) {
        
            for(int j = 0; j < n0; j++) {
                if(t[i-1] <= t_bleach[j] && t[i] > t_bleach[j]) {
                    bleach_count++;
                }   
            }   
        
            n[i] = n0 - bleach_count;
        }
        
        if(n[record_count-1] > 0) { 
            printf("\nTime series %d does not fully bleach with %d remaining fluors!\n", dataset, n[record_count-1]);        
            getchar();
        }
 
        /*
        // Generate flourophore count time series with timesteps that uniquely captures bleaches
        // Best used for sets with bleach times > O(10^-3)
        // ============================================================================================
        int min_dt_idx = find_min_idx(bleach_steps, n0);
        int ord = (int) log10(bleach_steps[min_dt_idx]); // determine order of smallest bleachstep

        // Determine timestep that captures all changepoints
        float dt_i;
        if(bleach_steps[min_dt_idx] < 1) {
            dt_i = pow(10, ord-1);
        } else {
            dt_i = pow(10, ord);
        }
        
        // set dt_i = dt_full if timesteps are larger than dt_full 
        if(dt_i > dt_full) dt_i = dt_full;
    
        printf("Timestep in n time series: %f\n", dt_i);
        
        // Declare arrays for time series n
        unsigned int n_record_count = ((record_count * dt_full) / dt_i) + 1; 
        int n[n_record_count];        
        double t_n[n_record_count];
        
        // Initialise n_t array
        n[0] = n0;
        t_n[0] = 0.0;
        for(int i = 1; i < n_record_count; i++) {
            t_n[i] = t_n[i-1] + dt_i;
        }
        
        // Generate fluorophore count distribution n
        int bleach_count = 0;
        for(int i = 1; i < n_record_count; i++) {
            
            for(int j = 0; j < n0; j++) {
                if(t_n[i-1] <= t_bleach[j] && t_n[i] > t_bleach[j]) {
                    bleach_count++;
                }   
            }   
        
            n[i] = n0 - bleach_count;
        }
        */

        // Generate intensity time series with weighted averages over the number of fluors with time
        // ============================================================================================
        int curr_idx, curr_n;
        curr_idx = 0;
        curr_n = n0;
        
        float t_prev, t_next, t_curr, n_full;

        // generate Gaussian noise for each timestep:
        double noise[record_count][2], noise_factor, sig_sq;
        gen_gauss_noise(record_count, noise);        

        // iterate through each intensity timestep
        for(int i = 0; i < record_count; i++) {
            
            // initialise start and end of stepstep, and next bleach event
            t_prev = t[i];
            t_next = t_prev + dt_full;
            t_curr = t_bleach[curr_idx];
            
            //printf("t_prev = %f, t_curr = %f, t_next = %f, curr_n = %d\n", t_prev, t_curr, t_next, curr_n);
            
            if(t_curr > t_prev && t_curr <= t_next) {
            //bleach events occur within current timestep 
                n_full = 0;
                 
                do {
                    // number of fluorophores for each intensity timestep is a weighted average
                    n_full += curr_n * (t_curr - t_prev) / dt_full;

                    // Decrement number of remaining fluors if not at the end of current timestep
                    if(t_curr < t_next) curr_n--;
                    
                    if(t_bleach[curr_idx+1] > t_next || curr_idx == (n0-1)) {
                    // no more bleaches after this one - calculate for time between current bleach and end of timestep
                        t_prev = t_curr;
                        t_curr = t_next;
                    } else {
                    // next bleach time within current timestep - calculate for time within current and next bleach time
                        curr_idx++;
                        t_prev = t_curr;
                        t_curr = t_bleach[curr_idx];
                    }
                 
                } while(t_prev < t_curr);
                curr_idx++;

            } else {   
            // np bleaching occurred, use current number of fluorophores in intensity calc
                n_full = curr_n;
            }
            
            //printf("n_full[%d] = %f\n", i, n_full); 
            
            // compute noise factor for each intensity timestep
            sig_sq = sig1_sq*n_full + sig0_sq;
            noise_factor = noise[i][0] * sqrt(sig_sq);
 
            // compute intensity for each timestep
            I[i] = nu*n_full + a + noise_factor;

        }

        // ============================================================================================
        
        // Output arrays and parameters to file
        save_n(n_output_path, record_count, t, n);
        //save_n(n_output_path, n_record_count, t_n, n); // for use with discretised n time series
        save_I(I_output_path, record_count, t, I);
        save_exp_fit_params(fit_params_output_path, n[0], nu, a, q, sig0_sq, sig1_sq, 0.0); 
        
        printf("\nGenerated set %d\n", dataset); 

    }
    
    printf("Completed.\n");
    
    return 0;
}
