/*
Author: Jon Garry
Date Created: 2016-05-10
Date Last Modified: 2016-06-06
Description: Utility functions used by other routines
*/

#include "utility_functions.h"


// RNG
unsigned long long rdtsc(){
// Function returns a random seed from processor cycle count
    unsigned int lo,hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return ((unsigned long long)hi << 32) | lo;
}

void save_seed(char *prog_name, char *fname, unsigned seed) {
// Save seed info with date and time to file
    FILE *fp;
    char path[] = "seeds.txt";
    time_t curr_time = time(NULL);


    // Output info to file
    fp = fopen(path, "a");

    if(fp == NULL) {
        printf("Unable to open seed list file. Exiting.\n");
        exit(1);
    }
    else {
        fprintf(fp, "%u %s %s %s", seed, prog_name, fname, ctime(&curr_time));
        fclose(fp);
    }
}

// math
int factorial(int n) {

    int retval = 1;

    if(n == 0) {
        return 1;
    }
    else {
        for(int i = 1; i<=n; i++) {
            retval*=i;
        }
        return retval;
    }
}

// arrays
void shuffle(int *arr, int length) {
// Function shuffles elements of an array using Fisher-Yates algorithm 

    int i = length - 1;
    int j, temp;

    while(i > 0) {
        j = random() % (i + 1);
        temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
        i = i - 1;
    }
}

void sort_asc(int *arr, int length) {
// Function sorts arrays in ascending order
    int tmp;

    for(int i=0; i<length; i++) {
        for(int j=0; j<length-1; j++) {
            
            if(arr[j] > arr[j+1]) {

                tmp=arr[j+1];
                arr[j+1] = arr[j];
                arr[j]=tmp;
            }
        } 
    }       
}

void sort_desc(int *arr, int length) {
// Function sorts arrays in descending order
    int tmp;

    for(int i=0; i<length; i++) {
        for(int j=0; j<length-1; j++) {

            if(arr[j] < arr[j+1]) {

                tmp=arr[j+1];
                arr[j+1] = arr[j];
                arr[j]=tmp;
            }   
        }   
    }
}

// file io
int get_record_count(char *path) {
// Get record count in dataset
    FILE *fp;
    int record_count = 0;
    char sample_chr;

    fp = fopen(path, "r");

    if(fp == NULL) {
        printf("Unable to open %s in function get_record_count(). Exiting.\n", path);
        exit(1);
    }
    else {
        while((sample_chr = fgetc(fp)) != EOF) {
            if(sample_chr == '\n')
                record_count++;
        }

    fclose(fp);
    }

    return record_count;
}

void load_exp_data(char *path, int record_count, double *I, double *t) {
// Load intensities and time series from experimental data
    FILE *fp;
    double *first_t = t;        // original ptr location
    
    fp = fopen(path, "r");

    if(fp == NULL) {
        printf("Unable to open %s in function load_exp_t(). Exiting.\n", path);
        exit(1);
    }
    else {
        for(int i = 0; i < record_count; i++)
        {   
            fscanf(fp, "%lf %lf\n", t, I);
            t++; // iterate pointer location
            I++;
        }
        fclose(fp);
        t = first_t; // reset pointer location
    }

    /*
    // Convert t from ms to s
    for(int i = 0; i < record_count; i++) {
        t[i] = t[i]/1000;
    }
    */
}

void load_test_data(char *path, int record_count, double *I, double *t) {
// Load intensities and time series from test data
    FILE *fp;
    double *first_t = t;        // original ptr location
    
    fp = fopen(path, "r");

    if(fp == NULL) {
        printf("Unable to open %s in function load_exp_t(). Exiting.\n", path);
        exit(1);
    }
    else {
        for(int i = 0; i < record_count; i++)
        {   
            fscanf(fp, "%lf %lf\n", t, I);
            t++; // iterate pointer location
            I++;
        }
        fclose(fp);
    }
}

void save_n(char *path, int record_count, double *t, int *n) {
// Output t and n arrays to file.
    FILE *fp;

    // Output t and n to file
    fp = fopen(path, "w");

    if(fp == NULL) {
        printf("Unable to open %s. Exiting.\n", path);
        exit(1);
    }
    else {
        for(int i = 0; i < record_count; i++) {
            fprintf(fp, "%f %d\n", t[i], n[i]);
        }   
        fclose(fp);
    }
}

void save_I(char *path, int record_count, double *t, double *I) {
// Output t and I to file
    FILE *fp;

    fp = fopen(path, "w");

    if(fp == NULL) {
        printf("Unable to open %s. Exiting.\n", path);
        exit(1);
    }
    else {
        for(int i = 0; i < record_count; i++) {
            fprintf(fp, "%f %lf\n", t[i], I[i]);
        }
        fclose(fp);
    }
}

void save_exp_fit_params(char *path, int n0, double nu, double a, double q, double sig0_sq, double sig1_sq, double L) {
// Output fitting parameters for file
    FILE *fp;

    fp = fopen(path, "w");

    if(fp == NULL) {
        printf("Unable to open %s. Exiting.\n", path);
    }
    else {
        fprintf(fp, "%d %f %f %f %f %f %f\n", n0, nu, a, q, sig0_sq, sig1_sq, L);
        fclose(fp);
    }
}

void load_exp_fit_params(char *path, int *n0, double *nu, double *a, double *q, double *sig0_sq, double *sig1_sq, double *L) {
// Load fitting parameters
    FILE *fp;
    fp = fopen(path, "r");

    if(fp == NULL) {
        printf("Unable to open %s. Exiting.\n", path);
        exit(1);
    }
    else {
        fscanf(fp, "%d %lf %lf %lf %lf %lf %lf\n", n0, nu, a, q, sig0_sq, sig1_sq, L);
    }

    fclose(fp);
}

void save_test_fit_params(char *path, int fnum, int n0, double nu, double a, double q, double sig0_sq, double sig1_sq, double L) {
// Output fitting parameters for file
    FILE *fp;

    fp = fopen(path, "w");

    if(fp == NULL) {
        printf("Unable to open %s. Exiting.\n", path);
    }
    else {
        fprintf(fp, "%d %d %f %f %f %f %f %f\n", fnum, n0, nu, a, q, sig0_sq, sig1_sq, L);
        fclose(fp);
    }
}

void save_n0_L(char *path, int n0, double L) {
// Save n0 and max L for each n0
    FILE *fp;

    // Output info to file
    fp = fopen(path, "a");

    if(fp == NULL) {
        printf("Unable to open %s. Exiting.\n", path);
        exit(1);
    }
    else {
        fprintf(fp, "%d %f\n", n0, L);
        fclose(fp);
    }
}

