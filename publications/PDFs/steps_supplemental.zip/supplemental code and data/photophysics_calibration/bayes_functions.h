/*
Author: Jon Garry
Date Created: 2016-05-11
Date Last Modified: 2017-05-08
Description: Header file for Bayesian fitting functions.
*/

#include <math.h>
#include "utility_functions.h"
#include <gsl/gsl_sf.h>

// General-purpose functions
void get_change_pts(int *n, int N, int *change_pts);
int find_max_idx(double *arr, int length);
int find_min_idx(double *arr, int length);
void remove_changepoint(int *n, int lbound, int ubound);
void add_changepoint(int *n, int lbound, int ubound);
int magitude(float x);

// Functions for fitting with an n-dependent noise model
double calc_L(int *n, double *I, int N, double nu, double a, double q, double sig0_sq, double sig1_sq);
void calc_params(int *n, double *I, int N, double *nu, double *a, double *q, double sig0_sq, double sig1_sq);
void calc_q(int *n, double *I, int N, double *q);
void calc_const_nu_a(int *n, double *I, int N, double *nu, double *a);
double bisection(double a, double b, double sig0_sq, int *n, double *m, int N);
double noise_func(double sig1_sq, double sig0_sq, int *n, double *m, int N);
void calc_var_noise(int *n, double *I, int N, double *sig0_sq, double *sig1_sq);

// Functions for fitting to noise ({n} = 0)
double calc_zero_L(double *I, int N, double a, double sig0_sq);
void calc_zero_params(double *I, int N, double *a, double *sig0_sq);
