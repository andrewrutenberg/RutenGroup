#!/bin/bash

fname='traj'
first=1
last=97

for ((i=$first; i<=$last; i=i+1))  
do
    ./calibrate $fname'_'$i  
done
