/*
Author: Jon Garry
Date Created: 2016-05-11
Date Last Modified: 2017-07-07
Description: Functions used for Bayesian fitting routine
*/

#include "bayes_functions.h"

// General-purpose functions

void get_change_pts(int *n, int N, int *change_pts) {
// Function for getting indices of changepoints in n dist
    int idx = 0;
    
    for(int i = 1; i < N; i++) {
        if(n[i-1] > n[i]) {
            // accounting for multiple bleaches in one time step
            for(int j = 0; j < (n[i-1] - n[i]); j ++) {
                change_pts[idx] = i;
                idx += 1;
            }
        }
    }
}

void remove_changepoint(int *n, int lbound, int ubound) {
// Function for removing a changepoint from within a given range
    for(int i = lbound; i < ubound; i++) {
        n[i] -= 1;
    }
}

void add_changepoint(int *n, int lbound, int ubound) {
// Function for adding a changepoint from within a given range
    for(int i = lbound; i < ubound; i++) {
        n[i] += 1;
    }
}

int find_max_idx(double *arr, int length) {
    
    double largest = arr[0];
    int index = 0;

    for(int i = 0; i < length; i++) {
        
        if (arr[i] > largest){
            index = i;
            largest = arr[i];
        }   
    }

    return index;
}

int find_min_idx(double *arr, int length) {
    
    double smallest = arr[0];
    int index = 0;

    for(int i = 0; i < length; i++) {
        
        if (arr[i] < smallest){
            index = i;
            smallest = arr[i];
        }   
    }

    return index;
}

// Functions for fitting with an n-dependent noise model
// =====================================================

double calc_L(int *n, double *I, int N, double nu, double a, double q, double sig0_sq, double sig1_sq) {
// Function for calculating the log-posterior
    double L, L1, L2, L3, L4, L5, sig_i_sq[N], n_avg;

    // Calculate noise over whole distribution
    for(int i = 0; i < N; i ++) {
        sig_i_sq[i] = (n[i] * sig1_sq) + sig0_sq;
    }
  
    double curr_L2 = 0; 
    L1 = 0;
    L2 = 0;
    for(int i = 0; i < N; i++) {
        L1 += (-1.0/2.0) * log(2 * M_PI * sig_i_sq[i]);
        L2 += -((I[i] - nu*n[i] - a) * (I[i] - nu*n[i] - a)) / (2 * sig_i_sq[i]); 
    }
    
    L3 = 0;
    L4 = 0;
    L5 = 0;
    for(int i = 1; i < N; i++) {

        // Calculating whole log of binomial coeff
        L3 += gsl_sf_lnchoose(n[i-1],n[i]);
        L4 += n[i] * log(q);
        L5 += (n[i-1] - n[i]) * log(1-q);
        
    } 
    
    L = L1 + L2 + L3 + L4 + L5;

    // Suppress NaN values
    if(isnan(L) || isinf(L)) {
        L = -9999999;
    }

    return L;
}


void calc_params(int *n, double *I, int N, double *nu, double *a, double *q, double sig0_sq, double sig1_sq) {
// Function for calculating parameters weighted with noise variance
    
    double weight = 0;
    double weight_n = 0;
    double weight_n_sq = 0;
    double weight_I = 0;
    double weight_nI = 0;
    double sig_i_sq[N];
    double n_avg, n_sq_avg, I_avg, nI_avg;
    double sig_n, sig_nI;
    double n_avg_uw = 0;  // unweighted average over n_i

    // Calculate noise over whole distribution
    for(int i = 0; i < N; i ++) {
        sig_i_sq[i] = (n[i] * sig1_sq) + sig0_sq;
    }
    
    // Calculate weighted and unweighted values
    for(int i = 0; i < N; i ++) {
        weight += 1.0 / sig_i_sq[i];
        weight_n += n[i] / sig_i_sq[i];
        weight_n_sq += (n[i] * n[i]) / sig_i_sq[i];
        weight_I += I[i] / sig_i_sq[i];
        weight_nI += (n[i] * I[i]) / sig_i_sq[i];
        n_avg_uw += n[i];
    }
    
    // Calculate weighted and unweighted means and variances
    n_avg = weight_n / weight;
    n_sq_avg = weight_n_sq / weight;
    I_avg = weight_I / weight;
    nI_avg = weight_nI / weight;
    n_avg_uw /= N;

    sig_n = n_sq_avg - (n_avg * n_avg);
    sig_nI = nI_avg - (n_avg * I_avg);

    *nu = sig_nI / sig_n;
    *a = I_avg - *nu * n_avg;
    *q = ((N * n_avg_uw) - n[0]) / ((N * n_avg_uw) - n[N-1]);
}

void calc_q(int *n, double *I, int N, double *q) {
// Function for calculating non-bleach probability q in prior over n_i
    
    double n_avg_uw = 0;  // unweighted average over n_i
    
    // Calculate weighted and unweighted values
    for(int i = 0; i < N; i ++) {
        n_avg_uw += n[i];
    }
    n_avg_uw /= N;

    *q = ((N * n_avg_uw) - n[0]) / ((N * n_avg_uw) - n[N-1]);
}

void calc_const_nu_a(int *n, double *I, int N, double *nu, double *a) {
// Function for calculating nu and a using constant noise model
    double n_avg, n_sq_avg, sig_n_sq;
    double I_avg;
    double nI_avg, sig_nI_sq;

    // Calculate averages
    n_avg = 0;
    n_sq_avg = 0;
    I_avg = 0;
    nI_avg = 0;

    for(int i = 0; i < N; i++) {
        n_avg += n[i];
        n_sq_avg += (n[i] * n[i]);
        I_avg += I[i];
        nI_avg += (n[i] * I[i]);
    }
    n_avg /= N;
    n_sq_avg /= N;
    I_avg /= N;
    nI_avg /= N;

    //Calculate variances
    sig_n_sq = n_sq_avg - (n_avg * n_avg);
    sig_nI_sq = nI_avg - (n_avg * I_avg);

    // Calculate parameters
    *nu = sig_nI_sq / sig_n_sq;
    *a = I_avg - (*nu * n_avg);
}

double bisection(double a, double b, double sig0_sq, int *n, double *m, int N) {
    int maxiter = 100;
    int iters = 0;
    double epsilon = 1e-4;      // target accuracy
    double c;                   // midpoint value

    // Check that function has opposite signs at the endpoints and over-estimate of sig1_sq > 0
    if((noise_func(a, sig0_sq, n, m, N) < 0) && (noise_func(b, sig0_sq, n, m, N) > 0) && (a >= 0)) {
        c = 0.5 * (a + b);

        while(((a-b) > epsilon) && (iters <= maxiter)) {
            
            if(noise_func(c, sig0_sq, n, m, N) == 0)
                return c;
            
            // Check if function has different signs at a and c
            else if((noise_func(a, sig0_sq, n, m, N) * noise_func(c, sig0_sq, n, m, N)) < 0)
                b = c;
            
            else
                a = c;

            c = 0.5 * (a + b);
            iters += 1;

            if(iters == maxiter) {
                printf("Maximum iterations in bisection routine reached...\n");
                printf("c = %f\n", c);
            }
        }
    }
    else {
        // Function has same sign at endpoints or a is negative, cannot find the root
        c = 0;
    }

    return c;
}

double noise_func(double sig1_sq, double sig0_sq, int *n, double *m, int N) {
// Root finding function    
    double retval = 0;

    for(int i = 0; i < N; i ++) {
        retval += m[i] / (n[i] * sig1_sq + sig0_sq);
    }
    retval /= N;

    return retval - 1;
}

void calc_var_noise(int *n, double *I, int N, double *sig0_sq, double *sig1_sq) {
// Function for calculating sig0_sq and sig1_sq using bisection method
    
    // Calculate nu and a using contant noise model for initial calculations
    double nu, a, q;
    calc_const_nu_a(n, I, N, &nu, &a);
    
    // Calculate m (m = (I-nu*n-a)^2) and m_avg
    double m[N], m_avg;
    m_avg = 0;
    for(int i = 0; i < N; i++) { 
        m[i] = (I[i] - nu*n[i] - a) * (I[i] - nu*n[i] - a);
        m_avg += m[i];
    }
    m_avg /= N;
    
    // Get index of last change point
    int change_pts[n[0]], last_pt;
    
    get_change_pts(n, N, change_pts);
    last_pt = change_pts[n[0]-1]; 
    
    // Create arrays for sig0_sq and sig1_sq values to try
    int slices = 100;
    double sig0_vals[slices], sig1_vals[slices], L_vals[slices];
    double incr = 0;
   
    for(int i = 0; i < slices; i++) {
        incr += m_avg / slices;
        sig0_vals[i] = incr;
    }
    
    // Sweep sig0_vals and calculate sig1_sq and log-posterior for each
    double sum_numerator, sum_denominator, sig1_est; 

    for(int i = 0; i < slices; i++) {
     
        // Calculate over-estimate of sig1_sq for negative endpoint in noise function   
        sum_numerator = 0;
        sum_denominator = 0;

        // sum over portion where n_0 != 0
        for(int j = 0; j < last_pt; j++) {
            sum_numerator += m[j] / n[j];
        }

        // sum over portion where n_0 = 0
        for(int j = last_pt; j < N; j++) {
            sum_denominator += (m[j] / sig0_vals[i]);
        }
        
        sig1_est = sum_numerator / (N - sum_denominator);
        
        // Estimate current sig1_sq value using bisection method
        sig1_vals[i] = bisection(sig1_est, 0, sig0_vals[i], n, m, N);
        
        // Calculate log-posterior with current sig1_sq and sig0_sq values
        calc_params(n, I, N, &nu, &a, &q, sig0_vals[i], sig1_vals[i]);
        L_vals[i] = calc_L(n, I, N, nu, a, q, sig0_vals[i], sig1_vals[i]);
    }
    
    // Find index with largest log-posterior value and set sig0_sq and sig1_sq
    int maxIdx = find_max_idx(L_vals, slices);
    *sig0_sq = sig0_vals[maxIdx];
    *sig1_sq = sig1_vals[maxIdx];
}

void calc_zero_params(double *I, int N, double *a, double *sig0_sq) {
// Function for calculating the parameters for zero fluorophores within a curve
    double I_avg = 0;
    double I_sq_avg = 0;
    
    for(int i = 0; i < N; i++) {
        I_avg += I[i];
        I_sq_avg += I[i] * I[i];
    }

    I_avg /= N;
    I_sq_avg /= N;
    
    // Calculate a and sig0_sq
    *a = I_avg;
    *sig0_sq = I_sq_avg - (I_avg * I_avg);
}

double calc_zero_L(double *I, int N, double a, double sig0_sq) {
// Function for calculating the log-posterior with zero fluorophores present
    double L1, L2;
    
    L1 = -N/2 * log(2 * M_PI * sig0_sq);

    L2 = 0;
    for(int i = 0; i < N; i++) {
        L2 -= ((I[i] - a) * (I[i] - a)) / (2 * sig0_sq);
    }
    
    return L1 + L2;
}
