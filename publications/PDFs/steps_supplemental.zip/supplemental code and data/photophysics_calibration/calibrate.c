/*
Author: Jon Garry
Date Created: 2016-05-10
Date Last Modified: 2017-09-22
Description:    Program for calibrating photophysics from experimental datasets with
                single fluorophore bleach events.
                Fitting is restricted to 0 or 1 fluorophore within a curve.
*/

#include <stdio.h>
#include <sys/stat.h>
#include <math.h>
#include <stdlib.h>
#include "utility_functions.h"
#include "bayes_functions.h"

static inline void loadBar(int x, int n, int r, int w);

int main(int argc, char *argv[]) {
     
    char fname[30], input_path[60], I_output_path[60], n_output_path[60], params_output_path[60];
    
    // Set up file names and paths
    // ============================

    // Ensure a file name was passed
    if(argc != 2) {
        printf("Usage for fitting a single dataset:\n./fitting_full filename (without the file extension)\n");
    } else {
        strcpy(fname, argv[1]);
    }
    
    // Set input path
    strcpy(input_path, "./data/");
    strcat(input_path, fname);
    strcat(input_path, ".txt");

    // Set output paths and make output directory
    strcpy(I_output_path, "./data/");
    strcat(I_output_path, fname);
    
    mode_t process_mask = umask(0);
    int result_code = mkdir(I_output_path, S_IRWXU | S_IRWXG | S_IRWXO);
    umask(process_mask);

    strcat(I_output_path, "/I_vs_t-fit.txt");

    strcpy(n_output_path, "./data/");
    strcat(n_output_path, fname);
    strcat(n_output_path, "/n_vs_t-fit.txt");

    strcpy(params_output_path, "./data/");
    strcat(params_output_path, fname);
    strcat(params_output_path, "/fit_params.txt");

    // Declare variables and load dataset
    int N = get_record_count(input_path);
    int n[N], max_idx;
    double I[N], I_fit[N], t[N], L[N-1], L0, L_max, nu, a, q, sig0_sq, sig1_sq;

    load_exp_data(input_path, N, I, t);
    
    // Calculate fit with n_0 = 0
    // ==================================
    calc_zero_params(I, N, &a, &sig0_sq);
    L0 = calc_zero_L(I, N, a, sig0_sq);
        
    // Fitting with n_0 = 1
    // =============================================================

    // Initialise array of fluorophore counts n
    for(int i=0; i<N; i++) {
        n[i] = 0;
    }

    // Cycle over all points moving the bleach step and calculating L 
    printf("\nFitting bleach step...\n");
    for(int i=0; i < N-1; i++) {
        
        // Move step location
        n[i] = 1;        

        // Calculate parameters and log-posterior
        calc_var_noise(n, I, N, &sig0_sq, &sig1_sq);
        calc_params(n, I, N, &nu, &a, &q, sig0_sq, sig1_sq);
        L[i] = calc_L(n, I, N, nu, a, q, sig0_sq, sig1_sq);

        loadBar(i, N, 10, 60);
    }

    // get location of maximum L
    max_idx = find_max_idx(L, sizeof(L)/sizeof(double));
    
    // ============================================================
    

    // Check if log-posterior is a maximum with 0 or 1 fluorophores:
    if(L0 > L[max_idx]) {
        L_max = L0;
   
        // Clear n array 
        for(int i=0; i<N; i++) {
            n[i] = 0;
        }
        
        // Set optimal parameters for zero fluorophores
        calc_zero_params(I, N, &a, &sig0_sq);
        nu = 0;
        q = 0;
        sig1_sq = 0;
    
    } else {
        L_max = L[max_idx];        

        // Reset n array and add step to location of maximum
        remove_changepoint(n, 0, N-1);
        add_changepoint(n, 0, max_idx+1); 
        
        // Recalculate parameters for output 
        calc_var_noise(n, I, N, &sig0_sq, &sig1_sq);
        calc_params(n, I, N, &nu, &a, &q, sig0_sq, sig1_sq);
    }

    // Generate fitting intenity trace
    for(int i = 0; i < N; i++) {
        I_fit[i] = nu*n[i] + a;
    }
    
    printf("\nFitting parameters:\n");
    printf("n_0 = %d\n", n[0]);
    printf("nu = %f\n", nu);
    printf("a = %f\n", a);
    printf("q = %f\n", q);
    printf("sig0_sq = %f\n", sig0_sq);
    printf("sig1_sq = %f\n", sig1_sq);
    printf("L = %f\n", L_max);
    
    // Save n and I traces to file
    save_n(n_output_path, N, t, n);
    save_I(I_output_path, N, t, I_fit);
    
    // Save fitting parameters to file
    save_exp_fit_params(params_output_path, n[0], nu, a, q, sig0_sq, sig1_sq, L_max); 
    
    return 0;
}

static inline void loadBar(int x, int n, int r, int w) {
// Function for displaying progress bar in the terminal
// Process has done x out of n rounds with a bar of width w and resolution r

    // Only update r times
    if ( x % (n/r) != 0 ) return;

    // Calculuate the ratio of complete-to-incomplete
    float ratio = x/(float)n;
    int   c     = ratio * w;

    // Show the percentage complete
    printf("%3d%% [", (int)(ratio*100));

    // Show the load bar.
    for (int x=0; x<c; x++)
       printf("=");

    for (int x=c; x<w; x++)
       printf(" ");

    // ANSI Control codes to go back to the
    // previous line and clear it.
    printf("]\n\033[F\033[J");
}

